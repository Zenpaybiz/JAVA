package com.Payfair.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PayfairApplicationTests {

	@Test
	void contextLoads() {
	}

}
