package com.Zenpay.demo;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import javax.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;



@Controller
public class Zenpayapi {
	
	Algorithm  a= new Algorithm();

	@GetMapping("/")
	public String get() {
		return "index";
	}

	@RequestMapping("/sendData")
	public String post(HttpServletRequest  parameter,Model req) throws UnsupportedEncodingException, NoSuchAlgorithmException {
		
		String salt = parameter.getParameter("salt");
		
		String url=parameter.getParameter("integrationtype");
		
		HashMap<String, String> request = new HashMap<String,String>();
		request.put("api_key",parameter.getParameter("api_key"));
		request.put("return_url",parameter.getParameter("return_url"));
		request.put("return_url_success",parameter.getParameter("return_url_success"));
		request.put("return_url_failure",parameter.getParameter("return_url_failure"));
		request.put("mode",parameter.getParameter("mode"));
		request.put("order_id",parameter.getParameter("order_id"));
		request.put("amount",parameter.getParameter("amount"));
		request.put("currency",parameter.getParameter("currency"));
		request.put("description",parameter.getParameter("description"));
		request.put("name",parameter.getParameter("name"));
		request.put("email",parameter.getParameter("email"));
		request.put("phone",parameter.getParameter("phone"));
		request.put("address1",parameter.getParameter("address1"));
		request.put("address2",parameter.getParameter("address2"));
		request.put("city",parameter.getParameter("city"));
		request.put("state",parameter.getParameter("state"));
		request.put("zip_code",parameter.getParameter("zip_code"));
		request.put("country",parameter.getParameter("country"));
		request.put("udf1",parameter.getParameter("udf1"));
		request.put("udf2",parameter.getParameter("udf2"));
		request.put("udf3",parameter.getParameter("udf3"));
		request.put("udf4",parameter.getParameter("udf4"));
		request.put("udf5",parameter.getParameter("udf5"));
		request.put("bank_code",parameter.getParameter("bank_code"));
		request.put("split_info",parameter.getParameter("split_info"));
		request.put("split_enforce_strict",parameter.getParameter("split_enforce_strict"));
		request.put("percent_tdr_by_user",parameter.getParameter("percent_tdr_by_user"));
		request.put("show_convenience_fee",parameter.getParameter("show_convenience_fee"));
		request.put("payment_options",parameter.getParameter("payment_options"));
		request.put("allowed_bank_codes",parameter.getParameter("allowed_bank_codes"));
		request.put("allowed_bins",parameter.getParameter("allowed_bins"));
		request.put("offer_code",parameter.getParameter("offer_code"));
		request.put("allowed_emi_tenure",parameter.getParameter("allowed_emi_tenure"));
		request.put("timeout_duration",parameter.getParameter("timeout_duration"));
		request.put("product_details",parameter.getParameter("product_details"));
		request.put("payment_page_display_text",parameter.getParameter("payment_page_display_text"));
		
		
		

        Set<Entry<String, String>> entrySet = request.entrySet();
        List<Entry<String, String>> requestlist = new ArrayList<Entry<String, String>>(entrySet);
        
        Collections.sort(requestlist, new SortByKeyAscending());
        
        String hashdata = "";
        
        for(Map.Entry<String, String> entry:requestlist)
            if(entry.getValue().length() >0) {
            	salt +='|'+ entry.getValue();
            	hashdata = a.getHashCodeFromString(salt);
            }
		
       req.addAttribute("request",request);
       req.addAttribute("hash",hashdata);
       req.addAttribute("url",url);
       
		return "post";

	}
	
	@PostMapping("/response")
	public String response(HttpServletRequest  callback,Model res) throws NoSuchAlgorithmException, UnsupportedEncodingException {
		
		String salt = ""; //place your salt here
		
		HashMap<String, String> response = new HashMap<String,String>();
		response.put("order_id",callback.getParameter("order_id"));
		response.put("amount",callback.getParameter("amount"));
		response.put("currency",callback.getParameter("currency"));
		response.put("description",callback.getParameter("description"));
		response.put("name",callback.getParameter("name"));
		response.put("email",callback.getParameter("email"));
		response.put("phone",callback.getParameter("phone"));
		response.put("address_line_1",callback.getParameter("address_line_1"));
		response.put("address_line_2",callback.getParameter("address_line_2"));
		response.put("city",callback.getParameter("city"));
		response.put("state",callback.getParameter("state"));
		response.put("country",callback.getParameter("country"));
		response.put("zip_code",callback.getParameter("zip_code"));
		response.put("udf1",callback.getParameter("udf1"));
		response.put("udf2",callback.getParameter("udf2"));
		response.put("udf3",callback.getParameter("udf3"));
		response.put("udf4",callback.getParameter("udf4"));
		response.put("udf5",callback.getParameter("udf5"));
		response.put("transaction_id",callback.getParameter("transaction_id"));
		response.put("payment_mode",callback.getParameter("payment_mode"));
		response.put("payment_channel",callback.getParameter("payment_channel"));
		response.put("payment_datetime",callback.getParameter("payment_datetime"));
		response.put("response_code",callback.getParameter("response_code"));
		response.put("response_message",callback.getParameter("response_message"));
		response.put("error_desc",callback.getParameter("error_desc"));
		response.put("cardmasked",callback.getParameter("cardmasked"));
		
		String hash = callback.getParameter("hash");
		
		 Set<Entry<String, String>> entrySet = response.entrySet();
	        List<Entry<String, String>> requestlist = new ArrayList<Entry<String, String>>(entrySet);
	        
	        Collections.sort(requestlist, new SortByKeyAscending());
	        
	        String hashdata = "";
	        
	        
	        
	        for(Map.Entry<String, String> entry:requestlist)
	            if(entry.getValue().length() >0) {
	            	salt +='|'+ entry.getValue();
	            	hashdata = a.getHashCodeFromString(salt);
	            }
	        
	        
	        
	        
	      
		
	        String matched= "HASH MISMATCHED";
	        if(hash.equals(hashdata)) {
	        	matched= "HASH MATCHED";
	        }
		
	        
	        res.addAttribute("matched",matched);
	        res.addAttribute("response",response);
        	return "response";
	}

}






class SortByKeyAscending implements Comparator<Map.Entry<String, String>>{
	 
    public int compare( Map.Entry<String,String> entry1, Map.Entry<String,String> entry2){
        return (entry1.getKey()).compareTo( entry2.getKey() );
    }
}

	