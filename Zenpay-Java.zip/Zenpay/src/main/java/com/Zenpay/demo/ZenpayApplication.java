package com.Zenpay.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZenpayApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZenpayApplication.class, args);
	}

}
